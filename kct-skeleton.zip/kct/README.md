# ING KCT - POC

Logic lives in `src/kct` (importable package). Notebooks in `notebooks/` are thin: import, call, display.

## Setup (once per environment)

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -e ".[convert,notebooks,dev]"
python -m ipykernel install --user --name kct --display-name "Python (kct)"
nbstripout --install --attributes .gitattributes   # strips notebook outputs on commit
cp .env.example .env                                 # fill in, never commit
```

In Jupyter pick the **Python (kct)** kernel, then run `notebooks/00_smoke_test_list_models.ipynb`.

## Rules
- No evidence data or notebook outputs in git (nbstripout + .gitignore enforce this).
- Only generated fake files in `fixtures/`.
