#!/usr/bin/env bash
# Environment probe for the KCT Jupyter box. Review output before sharing - redact hostnames/paths if needed.
echo "== OS / Python ==";   uname -a; head -2 /etc/os-release 2>/dev/null
for p in python3 python3.10 python3.11 python3.12; do command -v $p >/dev/null && echo "$p: $($p --version 2>&1)"; done
python3 -m venv --help >/dev/null 2>&1 && echo "venv: ok" || echo "venv: MISSING"
echo "== Privileges ==";    id; sudo -n true 2>/dev/null && echo "sudo: yes" || echo "sudo: no"
command -v apt-get >/dev/null && echo "apt-get: present"
echo "== Tools ==";         for t in git soffice libreoffice gcloud docker; do printf "%-12s %s\n" $t "$(command -v $t || echo '-')"; done
echo "== Jupyter ==";       jupyter --version 2>/dev/null | head -5; jupyter kernelspec list 2>/dev/null
echo "== pip config (internal index?) =="; pip config list 2>/dev/null; cat /etc/pip.conf 2>/dev/null
echo "== Proxy env ==";     env | grep -iE '^(https?|no)_proxy=' | sed 's/=.*@/=***@/'
echo "== Google auth hints =="
echo "GOOGLE_APPLICATION_CREDENTIALS=${GOOGLE_APPLICATION_CREDENTIALS:-<unset>}"
ls ~/.config/gcloud/application_default_credentials.json 2>/dev/null && echo "gcloud ADC file: present"
curl -s -m 3 -H 'Metadata-Flavor: Google' http://metadata.google.internal/computeMetadata/v1/project/project-id && echo " <- GCE metadata server reachable" || echo "GCE metadata server: no"
echo "== Outbound =="
for u in https://pypi.org https://europe-west4-aiplatform.googleapis.com https://bigquery.googleapis.com; do
  printf "%-50s %s\n" $u "$(curl -s -o /dev/null -m 5 -w '%{http_code}' $u || echo fail)"; done
echo "== Disk =="; df -h ~ | tail -1
