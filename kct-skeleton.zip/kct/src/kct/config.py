from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

REPO_ROOT = Path(__file__).resolve().parents[2]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=REPO_ROOT / ".env",
        env_prefix="KCT_",
        extra="ignore",
    )

    gcp_project: str | None = None
    gcp_location: str = "europe-west4"
    gemini_model: str | None = None
    gemini_base_url: str | None = None  # internal gateway, if ING uses one

    storage_backend: str = "local"  # "local" now, "gcs" after approval
    fixtures_dir: Path = REPO_ROOT / "fixtures"

    bq_dataset: str | None = None

    def public_view(self) -> dict:
        """Safe to display in a notebook - contains no credentials."""
        return self.model_dump(mode="json")


@lru_cache
def get_settings() -> Settings:
    return Settings()
