from functools import lru_cache

from google import genai
from google.genai import types

from kct.config import get_settings


@lru_cache
def get_client() -> genai.Client:
    """Gemini client in Vertex mode.

    Auth comes from Application Default Credentials, e.g. GOOGLE_APPLICATION_CREDENTIALS
    pointing to a service-account key. If ING exposes Vertex through an internal gateway,
    set KCT_GEMINI_BASE_URL.
    """
    s = get_settings()
    http_options = types.HttpOptions(base_url=s.gemini_base_url) if s.gemini_base_url else None
    return genai.Client(
        vertexai=True,
        project=s.gcp_project,
        location=s.gcp_location,
        http_options=http_options,
    )


def list_models() -> list[dict]:
    """Base (publisher) models visible to this project/location."""
    models = get_client().models.list(config={"query_base": True})
    return [
        {
            "name": m.name,
            "display_name": getattr(m, "display_name", None),
            "version": getattr(m, "version", None),
        }
        for m in models
    ]


def ping(model: str | None = None) -> str:
    """Tiny round trip to prove auth + model access work."""
    model = model or get_settings().gemini_model
    if not model:
        raise ValueError("Set KCT_GEMINI_MODEL in .env (pick one from list_models()).")
    resp = get_client().models.generate_content(model=model, contents="Reply with exactly: OK")
    return resp.text
